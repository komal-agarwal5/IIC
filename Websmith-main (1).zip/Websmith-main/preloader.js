$(window).on("load", function () {

    "use strict";
    
    setTimeout(function () {
        $(".mm").fadeOut("slow");
    }, 3000);
    
    });